//
//  FriendListViewController.m
//  FriendsBook
//
//  Created by Nilesh Malviya on 13/07/15.
//  Copyright (c) 2015 KM. All rights reserved.
//

#import "FriendListViewController.h"
#import "WebServiceViewController.h"
#import "CommonUtilityClass.h"
#import "WebViewController.h"


@interface FriendListViewController ()
@property (strong, nonatomic) IBOutlet UITableView *friendListTableView;
@property (nonatomic, assign) int selectedCell;
@property (strong, nonatomic) AddFriendViewController *addFrndCont;
@property (strong, nonatomic) WebServiceViewController *webSVC;
- (IBAction)addFriendButtonPressed:(id)sender;
@property (strong, nonatomic) IBOutlet UISearchBar *searchBar;
@property (strong, nonatomic) NSMutableArray *frndArray;
@property (strong, nonatomic) WebViewController *webVC;
- (IBAction)webViewClicked:(id)sender;
- (IBAction)urlClicked:(id)sender;

@end

@implementation FriendListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(detailsSaveNotification) name:@"DetailUpdated" object:nil];
    self.addFrndCont = [[AddFriendViewController alloc] initWithNibName:@"AddFriendViewController" bundle:nil];
    self.addFrndCont.delegate = self;
    self.webSVC = [[WebServiceViewController alloc] initWithNibName:@"WebServiceViewController" bundle:nil];
    self.webVC = [[WebViewController alloc]initWithNibName:@"WebViewController" bundle:nil];
    self.frndArray = [[NSMutableArray alloc]init];
    self.selectedCell = -1;
}

- (void)viewWillAppear:(BOOL)animated{
    [self.frndArray removeAllObjects];
    [self.frndArray addObjectsFromArray:[[CommonUtilityClass sharedManager] frndArray]];
    [self.friendListTableView reloadData];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (IBAction)addFriendButtonPressed:(id)sender {
    self.addFrndCont.mode = @"add";
    [self.navigationController pushViewController:self.addFrndCont animated:YES];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self.frndArray count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    
    UITableViewCell *cell = [self.friendListTableView dequeueReusableCellWithIdentifier:@"MyIdentifier"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"MyIdentifier"];
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
    }
    if (self.selectedCell == indexPath.row) {
        cell.backgroundColor = [UIColor lightGrayColor];
    }else{
        cell.backgroundColor = [UIColor clearColor];
    }
    cell.textLabel.text = [[self.frndArray objectAtIndex:indexPath.row] objectAtIndex:0];
    return cell;
}
//- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section; {
//    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 1024, 40)];
//    view.backgroundColor = [UIColor redColor];
//    return view;
//}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    self.selectedCell = (int)indexPath.row;
    [self.friendListTableView reloadData];
    self.addFrndCont.mode = @"edit";
    [self.addFrndCont.frndDetailArray removeAllObjects];
    [self.addFrndCont.frndDetailArray addObjectsFromArray:[self.frndArray objectAtIndex:indexPath.row]];
    [self.navigationController pushViewController:self.addFrndCont animated:YES];

}
- (void)highlightNewlyAddedRecords{
    self.selectedCell = (int)[[[CommonUtilityClass sharedManager] frndArray] count] - 1;
    [self.friendListTableView reloadData];
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText{
    if ([searchText isEqualToString:@""]) {
        [self.frndArray removeAllObjects];
        [self.frndArray addObjectsFromArray:[[CommonUtilityClass sharedManager] frndArray]];
    }else{
        NSString *searchOption = searchBar.text;
        [self.frndArray removeAllObjects];
        for (int i = 0; i < [[CommonUtilityClass sharedManager] frndArray].count; i++) {
            NSString *name = [[[[CommonUtilityClass sharedManager] frndArray] objectAtIndex:i] objectAtIndex:0];
            if ([name hasPrefix:searchOption]) {
                NSArray *array = [[NSArray alloc]initWithObjects:name, nil];
                [self.frndArray addObject:array];
                [self.friendListTableView reloadData];
            }
        }
    }
    [self.friendListTableView reloadData];
}
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar{
    
}
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    
}
- (IBAction)webViewClicked:(id)sender {
    [self.navigationController pushViewController:self.webVC animated:YES];
}

- (IBAction)urlClicked:(id)sender {
    // TO DO use presentViewController instead of pushViewController.
//    [self presentViewController:self.webSVC animated:YES completion:nil];
    [self.navigationController pushViewController:self.webSVC animated:YES];
}
- (void)detailsSaveNotification{
    NSLog(@"Details Save");
}
@end
