//
//  WebViewController.m
//  FriendsBook
//
//  Created by Nilesh Malviya on 14/07/15.
//  Copyright (c) 2015 KM. All rights reserved.
//

#import "WebViewController.h"

@interface WebViewController ()<UIWebViewDelegate>
@property (nonatomic, strong) UIWebView *webView;
@end

@implementation WebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    NSString *urlString = @"http://echo.jsontest.com/key/value/otherkey/othervalue";
    NSString *urlString = @"http://www.google.com";
    NSURL *url = [[NSURL alloc]initWithString:urlString];
    NSURLRequest *urlRequest = [[NSURLRequest alloc]initWithURL:url];
    
    self.webView = [[UIWebView alloc]initWithFrame:CGRectMake(200, 200, 500, 500)];
    self.webView.delegate = self;
    [self.webView loadRequest:urlRequest];
    [self.view addSubview:self.webView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
//- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType;
- (void)webViewDidStartLoad:(UIWebView *)webView{
    
}
- (void)webViewDidFinishLoad:(UIWebView *)webView{
    
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    
}
@end
