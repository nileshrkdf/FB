//
//  AddFriendViewController.h
//  FriendsBook
//
//  Created by Nilesh Malviya on 13/07/15.
//  Copyright (c) 2015 KM. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol UpdateTableSelection <NSObject>

- (void)highlightNewlyAddedRecords;


@end
@interface AddFriendViewController : UIViewController

@property (weak, nonatomic) id <UpdateTableSelection> delegate;
@property (nonatomic, strong) NSString *mode;
@property (nonatomic,strong) NSMutableArray *frndDetailArray;
@end
